<?php
/**
 * @package shorturl
 */
class ShortUrlItem extends xPDOSimpleObject {}
?>