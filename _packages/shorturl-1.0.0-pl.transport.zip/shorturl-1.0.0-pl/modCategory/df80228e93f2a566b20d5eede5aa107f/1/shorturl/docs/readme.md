
shortUrl

Author: Jan Dähne <https://www.quadro-system.de>
Copyright 2022

Official Documentation: https://www.quadro-system.de/modx-extras/shorturl/

Bugs and Feature Requests: https://github.com:jdaehne/shortUrl

Questions: http://forums.modx.com
